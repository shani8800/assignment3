package com.example.raja_zeeshan;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
