import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
class drawer_start extends StatelessWidget {
  const drawer_start.drawer_start({super.key});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      elevation: 10,
      width: 265,
      shadowColor: Colors.blue,
      child: Container(
        color: Colors.blue[100],
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            DrawerHeader(decoration:
            BoxDecoration(
              color: Colors.blue[50],
            ),
              child: const Icon(CupertinoIcons.profile_circled),
            ),
            const ListTile(
              shape: StadiumBorder(side: BorderSide(color: Colors.black,width: 2)),
              leading: Icon(Icons.home,color: Colors.white,),
              title: Text('Home'),
            ),
            const ListTile( leading: Icon(Icons.settings,color: Colors.white,),
              title: Text('Settings'),
            ),
          ],

        ),
      ),
    );
  }
}
