import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class GridIcons {
  static List<Icon> iconlist = [
    const Icon(Icons.home),
    const Icon(Icons.favorite),
    const Icon(Icons.search),
    const Icon(Icons.person),
    const Icon(Icons.settings),
    const Icon(Icons.more_horiz),
    const Icon(Icons.calendar_today),
    const Icon(Icons.assignment_turned_in),
    const Icon(Icons.email),
    const Icon(Icons.notifications),
    const Icon(Icons.info),
    const Icon(Icons.help_outline),
    const Icon(Icons.exit_to_app),
    const Icon(Icons.menu),
    const Icon(Icons.account_circle),
    const Icon(Icons.account_balance_wallet),
    const Icon(Icons.account_box),
  ];
}

class IconGridPage extends StatelessWidget {
  const IconGridPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Grid View of Icons'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: GridView.builder(
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 3, // Number of columns
            crossAxisSpacing: 10.0,
            mainAxisSpacing: 10.0,
          ),
          itemCount: GridIcons.iconlist.length,
          itemBuilder: (context, index) {
            return Card(
              elevation: 2.0,
              child: Center(
                child: GridIcons.iconlist[index],
              ),
            );
          },
        ),
      ),
    );
  }
}
