import 'package:flutter/material.dart';

class BirthdayCardPage extends StatelessWidget {
  const BirthdayCardPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Layouts'),
        actions: [
          IconButton(
            icon: const Icon(Icons.share),
            onPressed: () {
              // Action for sharing
            },
          ),
          IconButton(
            icon: const Icon(Icons.more_vert),
            onPressed: () {
              // Action for more options
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Main image
              Image.asset('assets/images/birthday.png', fit: BoxFit.cover),

              const SizedBox(height: 16.0),

              // Title and description
              const Text(
                'My Birthday',
                style: TextStyle(fontSize: 24.0, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8.0),
              const Text(
                'It’s going to be a great birthday. We are going out for dinner at my favorite place, '
                    'then watch a movie after we go to the gelateria for ice cream and espresso.',
              ),

              const SizedBox(height: 16.0),

              // Weather and location info
              const Row(
                children: [
                  Icon(Icons.wb_sunny, color: Colors.orange),
                  SizedBox(width: 8.0),
                  Text(
                    '81° Clear',
                    style: TextStyle(fontSize: 16.0),
                  ),
                  Spacer(),
                  Icon(Icons.location_on, color: Colors.red),
                  SizedBox(width: 4.0),
                  Expanded(
                    child: Text(
                      '4500 San Alpho Drive, Dallas, TX United States',
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(fontSize: 16.0),
                    ),
                  ),
                ],
              ),

             const Padding(
               padding: EdgeInsets.all(8.0),
               child: Wrap(
                 children: [
                   Chip(label: Text('Gift   1')),
                   Chip(label: Text('Gift   2')),
                   Chip(label: Text('Gift   3')),
                   Chip(label: Text('Gift   4')),
                   Chip(label: Text('Gift   5')),
                   Chip(label: Text('Gift   6')),
                   Chip(label: Text('Gift   7')),
                   Chip(label: Text('Gift   8')),
                 ],
               ),
             )
              // Row of circular images

            ],
          ),
        ),
      ),
    );
  }
}
