import 'package:flutter/material.dart';
import 'birthdaypage.dart';
import 'sliver.dart';

import 'drawer.dart';
import 'icons.dart';
class home extends StatefulWidget {
  const home({super.key});

  @override
  State<home> createState() => _homeState();
}

class _homeState extends State<home> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Car Rentals '),centerTitle: true,backgroundColor: Colors.blueAccent[100],),
      drawer: const drawer_start.drawer_start(),
      body: Column(
        children: [
          GestureDetector(
            onTap: (){
              Navigator.push(context, MaterialPageRoute(builder: (context) => const IconGridPage()));
            },
            child: Container(
              height: 100,
              width: 200,
              margin: const EdgeInsets.all(20),
              child: const Card(
                elevation: 9,
                child: Stack(
                    children:
                [

                  Image(image: AssetImage('assets/images/car_rental.png'),height: double.infinity,width: double.infinity,),
                ]
                ),
              ),
            ),
          ),
          GestureDetector(
            onTap: (){
              Navigator.push(context, MaterialPageRoute(builder: (context) => const CustomScrollViewPage()));
            },
            child: Container(
              height: 100,
              width: 200,
              margin: const EdgeInsets.all(20),
              child: const Card(
                elevation: 9,
                child: Stack(
                    children:
                    [

                      Image(image: AssetImage('assets/images/car.png'),height: double.infinity,width: double.infinity,),
                    ]
                ),
              ),
            ),
          ),
          GestureDetector(
            onTap: (){
              Navigator.push(context, MaterialPageRoute(builder: (context) => const BirthdayCardPage()));
            },
            child: Container(
              height: 100,
              width: 200,
              margin: const EdgeInsets.all(20),
              child: const Card(
                elevation: 9,
                child: Stack(
                    children:
                    [

                      Image(image: AssetImage('assets/images/birthday.png'),height: double.infinity,width: double.infinity,),
                    ]
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
