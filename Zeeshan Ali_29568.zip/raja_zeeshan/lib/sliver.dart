import 'package:flutter/material.dart';

class CustomScrollViewPage extends StatelessWidget {
  const CustomScrollViewPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomScrollView(
        slivers: [
          // AppBar with Parallax Effect
          SliverAppBar(
            expandedHeight: 200.0,
            floating: false,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              title: const Text('CustomScrollView - Slivers'),
              background: Image.asset(
                'assets/images/parallax_image.png',
                fit: BoxFit.cover,
              ),
            ),
          ),
          // ListView with rows and titles
          SliverList(
            delegate: SliverChildListDelegate(
              [
                const ListTile(
                  leading: CircleAvatar(child: Text('1')),
                  title: Text('Row 1'),
                  subtitle: Text('Subtitle 1'),
                  trailing: Icon(Icons.star_border),
                ),
                const ListTile(
                  leading: CircleAvatar(child: Text('2')),
                  title: Text('Row 2'),
                  subtitle: Text('Subtitle 2'),
                  trailing: Icon(Icons.star_border),
                ),
                const ListTile(
                  leading: CircleAvatar(child: Text('3')),
                  title: Text('Row 3'),
                  subtitle: Text('Subtitle 3'),
                  trailing: Icon(Icons.star_border),
                ),
              ],
            ),
          ),
          // Grid View with icons
          SliverGrid(
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              crossAxisSpacing: 10.0,
              mainAxisSpacing: 10.0,
            ),
            delegate: SliverChildBuilderDelegate(
                  (BuildContext context, int index) {
                return const Card(
                  elevation: 2.0,
                  child: Center(
                    child: Icon(
                      Icons.pets,
                      color: Colors.amber,
                      size: 40.0,
                    ),
                  ),
                );
              },
              childCount: 12, // Number of grid items
            ),
          ),
        ],
      ),
    );
  }
}
